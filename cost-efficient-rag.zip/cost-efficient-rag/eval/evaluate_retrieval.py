"""
Retrieval-quality metrics computed against a fixed eval_dataset.json.

Each eval item looks like:
{
  "question": "...",
  "ground_truth_answer": "...",
  "relevant_chunk_ids": ["<chunk_id>", ...]
}

Run standalone:  python -m eval.evaluate_retrieval
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.vector_store import VectorStoreManager  # noqa: E402
from src.config import settings  # noqa: E402


def compute_recall_at_k(retrieved_ids: List[str], gold_ids: List[str], k: int) -> float:
    """Fraction of gold-relevant chunks present in the top-k retrieved set."""
    top_k_retrieved = set(retrieved_ids[:k])
    relevant_set = set(gold_ids)
    if not relevant_set:
        return 0.0
    hits = len(top_k_retrieved.intersection(relevant_set))
    return hits / len(relevant_set)


def compute_hit_rate(retrieved_ids: List[str], gold_ids: List[str], k: int) -> float:
    """1.0 if at least one relevant chunk appears in top-k, else 0.0."""
    top_k_retrieved = set(retrieved_ids[:k])
    relevant_set = set(gold_ids)
    return 1.0 if top_k_retrieved.intersection(relevant_set) else 0.0


def compute_mrr(retrieved_ids: List[str], gold_ids: List[str]) -> float:
    relevant_set = set(gold_ids)
    for index, item_id in enumerate(retrieved_ids):
        if item_id in relevant_set:
            return 1.0 / (index + 1)
    return 0.0


def compute_ndcg_at_k(retrieved_ids: List[str], gold_ids: List[str], k: int) -> float:
    """Binary relevance nDCG@k."""
    relevant_set = set(gold_ids)
    top_k = retrieved_ids[:k]

    dcg = 0.0
    for i, item_id in enumerate(top_k):
        rel = 1.0 if item_id in relevant_set else 0.0
        dcg += rel / math.log2(i + 2)  # i+2 because position is 1-indexed and log2(1)=0

    ideal_hits = min(len(relevant_set), k)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_hits))
    if idcg == 0:
        return 0.0
    return dcg / idcg


def compute_context_precision(retrieved_ids: List[str], gold_ids: List[str], k: int) -> float:
    """Of the chunks we actually retrieved (<=k), what fraction were relevant."""
    top_k = retrieved_ids[:k]
    if not top_k:
        return 0.0
    relevant_set = set(gold_ids)
    relevant_count = sum(1 for item_id in top_k if item_id in relevant_set)
    return relevant_count / len(top_k)


def evaluate_dataset(eval_path: str = "data/eval_dataset.json", k: int = 5) -> Dict:
    store = VectorStoreManager()
    with open(eval_path, "r", encoding="utf-8") as f:
        items = json.load(f)

    per_question = []
    for item in items:
        results = store.search(item["question"], top_k=k)
        retrieved_ids = [r["id"] for r in results]
        gold_ids = item["relevant_chunk_ids"]

        per_question.append(
            {
                "question": item["question"],
                "recall_at_k": compute_recall_at_k(retrieved_ids, gold_ids, k),
                "hit_rate": compute_hit_rate(retrieved_ids, gold_ids, k),
                "mrr": compute_mrr(retrieved_ids, gold_ids),
                "ndcg_at_k": compute_ndcg_at_k(retrieved_ids, gold_ids, k),
                "context_precision": compute_context_precision(retrieved_ids, gold_ids, k),
            }
        )

    def _avg(key: str) -> float:
        return round(sum(p[key] for p in per_question) / len(per_question), 4) if per_question else 0.0

    summary = {
        "k": k,
        "num_questions": len(per_question),
        "mean_recall_at_k": _avg("recall_at_k"),
        "mean_hit_rate": _avg("hit_rate"),
        "mean_mrr": _avg("mrr"),
        "mean_ndcg_at_k": _avg("ndcg_at_k"),
        "mean_context_precision": _avg("context_precision"),
    }

    return {"summary": summary, "per_question": per_question}


if __name__ == "__main__":
    out = evaluate_dataset(k=settings.default_top_k)
    print(json.dumps(out["summary"], indent=2))
    Path("results").mkdir(exist_ok=True)
    with open("results/retrieval_eval_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
