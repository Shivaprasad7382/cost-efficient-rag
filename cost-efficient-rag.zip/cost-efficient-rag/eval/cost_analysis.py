"""
Cost & latency analysis.

1. Theoretical monthly storage-cost model: embedded/self-hosted (disk +
   shared compute) vs a managed vector DB (always-on pod pricing tiers),
   at 100K / 1M / 10M vector scale.
2. Empirical p50/p95 retrieval + generation latency pulled from the
   query log written by src/logger.py during real usage / eval runs.

Run standalone:  python -m eval.cost_analysis
"""
from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.logger import read_query_log  # noqa: E402

# ---------------------------------------------------------------------------
# Stated assumptions (edit these to match your real deployment target)
# ---------------------------------------------------------------------------
ASSUMPTIONS = {
    "vector_dim": 384,
    "bytes_per_float": 4,  # float32
    "metadata_bytes_per_vector": 500,  # ~0.5 KB of text/metadata per chunk
    "disk_cost_per_gb_month_usd": 0.08,  # generic SSD-backed block storage (e.g. AWS EBS gp3)
    "shared_compute_cost_usd": 25.0,  # small always-on VM/container amortized share, flat regardless of scale in this range
    "query_volume_per_month": 50_000,
    "managed_db_pricing_tiers": {
        # illustrative Pinecone-style serverless/pod pricing bands
        100_000: 70.0,
        1_000_000: 280.0,
        10_000_000: 1200.0,
    },
}


def estimate_monthly_cost(vector_count: int, assumptions: Dict = ASSUMPTIONS) -> Dict:
    dim = assumptions["vector_dim"]
    bpf = assumptions["bytes_per_float"]
    meta_bytes = assumptions["metadata_bytes_per_vector"]

    raw_vector_bytes = vector_count * dim * bpf
    metadata_bytes = vector_count * meta_bytes
    total_gb = (raw_vector_bytes + metadata_bytes) / (1024 ** 3)

    disk_cost = total_gb * assumptions["disk_cost_per_gb_month_usd"]
    embedded_total_cost = disk_cost + assumptions["shared_compute_cost_usd"]

    tiers = sorted(assumptions["managed_db_pricing_tiers"].items())
    managed_cost = tiers[-1][1]
    for threshold, price in tiers:
        if vector_count <= threshold:
            managed_cost = price
            break

    savings_pct = (1 - (embedded_total_cost / managed_cost)) * 100 if managed_cost else 0.0

    return {
        "vector_count": vector_count,
        "storage_size_gb": round(total_gb, 3),
        "embedded_disk_cost_usd": round(disk_cost, 2),
        "embedded_compute_cost_usd": assumptions["shared_compute_cost_usd"],
        "embedded_total_cost_usd": round(embedded_total_cost, 2),
        "managed_db_cost_usd": managed_cost,
        "savings_usd": round(managed_cost - embedded_total_cost, 2),
        "savings_percentage": round(savings_pct, 2),
    }


def build_cost_table(scales: List[int] = (100_000, 1_000_000, 10_000_000)) -> List[Dict]:
    return [estimate_monthly_cost(n) for n in scales]


def _percentile(values: List[float], pct: float) -> float:
    if not values:
        return 0.0
    values = sorted(values)
    idx = int(round((pct / 100) * (len(values) - 1)))
    return values[idx]


def latency_report() -> Dict:
    events = read_query_log()
    retrieval = [e["retrieval_latency_ms"] for e in events if "retrieval_latency_ms" in e]
    generation = [e["generation_latency_ms"] for e in events if "generation_latency_ms" in e]
    return {
        "num_logged_queries": len(events),
        "retrieval_p50_ms": round(_percentile(retrieval, 50), 2),
        "retrieval_p95_ms": round(_percentile(retrieval, 95), 2),
        "generation_p50_ms": round(_percentile(generation, 50), 2),
        "generation_p95_ms": round(_percentile(generation, 95), 2),
    }


def render_markdown_table(cost_rows: List[Dict]) -> str:
    header = "| Vectors | Storage (GB) | Embedded cost/mo | Managed DB cost/mo | Savings | Savings % |\n"
    header += "|---|---|---|---|---|---|\n"
    lines = [header]
    for row in cost_rows:
        lines.append(
            f"| {row['vector_count']:,} | {row['storage_size_gb']} | "
            f"${row['embedded_total_cost_usd']} | ${row['managed_db_cost_usd']} | "
            f"${row['savings_usd']} | {row['savings_percentage']}% |\n"
        )
    return "".join(lines)


if __name__ == "__main__":
    cost_rows = build_cost_table()
    latency = latency_report()

    print(json.dumps({"assumptions": ASSUMPTIONS, "cost_table": cost_rows, "latency": latency}, indent=2))

    Path("results").mkdir(exist_ok=True)
    with open("results/cost_benchmark_table.md", "w", encoding="utf-8") as f:
        f.write("# Cost & Latency Benchmark\n\n")
        f.write("## Stated assumptions\n\n")
        f.write("```json\n" + json.dumps(ASSUMPTIONS, indent=2) + "\n```\n\n")
        f.write("## Monthly cost: embedded (ChromaDB, disk-backed) vs managed vector DB\n\n")
        f.write(render_markdown_table(cost_rows))
        f.write("\n## Observed query latency (from logs/query_log.jsonl)\n\n")
        f.write(f"- p50 retrieval: {latency['retrieval_p50_ms']} ms\n")
        f.write(f"- p95 retrieval: {latency['retrieval_p95_ms']} ms\n")
        f.write(f"- p50 generation: {latency['generation_p50_ms']} ms\n")
        f.write(f"- p95 generation: {latency['generation_p95_ms']} ms\n")
        f.write(f"- based on {latency['num_logged_queries']} logged queries\n")
