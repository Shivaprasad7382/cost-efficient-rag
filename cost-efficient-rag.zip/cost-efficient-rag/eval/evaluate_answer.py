"""
Answer-quality evaluation.

1. LLM-as-judge: faithfulness/groundedness (is every claim supported by the
   retrieved context?) and answer relevance (does the answer address the
   question?), each scored 1-5 with a rationale.
2. Exact-match / token-F1 against `ground_truth_answer`, for datasets that
   have a short-form gold answer (useful as a cheap, deterministic sanity
   metric alongside the LLM judge).

Run standalone:  python -m eval.evaluate_answer
"""
from __future__ import annotations

import json
import re
import string
import sys
from collections import Counter
from pathlib import Path
from typing import Dict, List

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.config import settings  # noqa: E402
from src.rag_pipeline import RAGPipeline  # noqa: E402
from src.vector_store import VectorStoreManager  # noqa: E402

JUDGE_SYSTEM_PROMPT = """You are a strict evaluator of RAG (retrieval-augmented generation) answers.
Given a QUESTION, the CONTEXT chunks that were retrieved, and the generated ANSWER, score two things
on a 1-5 integer scale:

- faithfulness: does every factual claim in the ANSWER trace back to something stated in CONTEXT?
  1 = mostly unsupported/hallucinated, 5 = fully grounded, no unsupported claims.
- relevance: does the ANSWER actually address the QUESTION asked?
  1 = off-topic or non-answer, 5 = directly and completely answers the question.

Respond with ONLY valid JSON, no markdown fences, no extra text, matching exactly:
{"faithfulness": <int 1-5>, "faithfulness_rationale": "<one sentence>", "relevance": <int 1-5>, "relevance_rationale": "<one sentence>"}
"""


def _normalize_text(s: str) -> str:
    s = s.lower()
    s = "".join(ch for ch in s if ch not in string.punctuation)
    s = re.sub(r"\b(a|an|the)\b", " ", s)
    return " ".join(s.split())


def exact_match(prediction: str, gold: str) -> float:
    return 1.0 if _normalize_text(prediction) == _normalize_text(gold) else 0.0


def token_f1(prediction: str, gold: str) -> float:
    pred_tokens = _normalize_text(prediction).split()
    gold_tokens = _normalize_text(gold).split()
    if not pred_tokens or not gold_tokens:
        return float(pred_tokens == gold_tokens)
    common = Counter(pred_tokens) & Counter(gold_tokens)
    num_same = sum(common.values())
    if num_same == 0:
        return 0.0
    precision = num_same / len(pred_tokens)
    recall = num_same / len(gold_tokens)
    return 2 * precision * recall / (precision + recall)


def judge_answer(question: str, context_chunks: List[str], answer: str) -> Dict:
    """
    Calls Anthropic as an impartial judge. Falls back to a neutral
    placeholder verdict (clearly marked) if no API key / network is
    available, so the harness never crashes.
    """
    context_block = "\n\n".join(context_chunks) if context_chunks else "(no context retrieved)"
    user_prompt = f"QUESTION:\n{question}\n\nCONTEXT:\n{context_block}\n\nANSWER:\n{answer}"

    try:
        import anthropic

        client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
        response = client.messages.create(
            model=settings.generation_model,
            max_tokens=300,
            system=JUDGE_SYSTEM_PROMPT,
            messages=[{"role": "user", "content": user_prompt}],
        )
        text = "".join(b.text for b in response.content if b.type == "text").strip()
        text = re.sub(r"^```(json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
        parsed = json.loads(text)
        parsed["judge_error"] = None
        return parsed
    except Exception as exc:
        return {
            "faithfulness": None,
            "faithfulness_rationale": None,
            "relevance": None,
            "relevance_rationale": None,
            "judge_error": f"{exc.__class__.__name__}: judge unavailable (set ANTHROPIC_API_KEY)",
        }


def evaluate_answers(eval_path: str = "data/eval_dataset.json", k: int = 5) -> Dict:
    store = VectorStoreManager()
    pipeline = RAGPipeline(store=store)

    with open(eval_path, "r", encoding="utf-8") as f:
        items = json.load(f)

    per_question = []
    for item in items:
        result = pipeline.answer(item["question"], top_k=k)
        context_texts = [c["source"] for c in result["citations"]]  # citations only carry metadata
        # re-fetch raw chunk text for judging (citations struct is metadata-only)
        raw_chunks = store.search(item["question"], top_k=k)
        raw_texts = [c["text"] for c in raw_chunks if c["similarity"] >= settings.similarity_threshold]

        verdict = judge_answer(item["question"], raw_texts, result["answer"])

        row = {
            "question": item["question"],
            "generated_answer": result["answer"],
            "fallback_triggered": result["fallback_triggered"],
            "faithfulness": verdict["faithfulness"],
            "relevance": verdict["relevance"],
            "judge_error": verdict.get("judge_error"),
        }

        if "ground_truth_answer" in item and item["ground_truth_answer"]:
            row["exact_match"] = exact_match(result["answer"], item["ground_truth_answer"])
            row["f1"] = round(token_f1(result["answer"], item["ground_truth_answer"]), 4)

        per_question.append(row)

    def _avg(key: str):
        vals = [p[key] for p in per_question if p.get(key) is not None]
        return round(sum(vals) / len(vals), 4) if vals else None

    summary = {
        "num_questions": len(per_question),
        "mean_faithfulness": _avg("faithfulness"),
        "mean_relevance": _avg("relevance"),
        "mean_exact_match": _avg("exact_match"),
        "mean_f1": _avg("f1"),
        "fallback_rate": round(sum(1 for p in per_question if p["fallback_triggered"]) / len(per_question), 4)
        if per_question
        else 0.0,
    }

    return {"summary": summary, "per_question": per_question}


if __name__ == "__main__":
    out = evaluate_answers(k=settings.default_top_k)
    print(json.dumps(out["summary"], indent=2))
    Path("results").mkdir(exist_ok=True)
    with open("results/answer_eval_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
