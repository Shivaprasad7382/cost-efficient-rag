# Cost-Efficient RAG Application

A QA service over a document corpus backed by **ChromaDB** (embedded,
disk-persisted, no always-on server/pod), with a full evaluation harness
covering retrieval quality, answer quality, and cost/latency at scale.

## Vector store choice: ChromaDB

Chosen over LanceDB / FAISS / pgvector / sqlite-vec because it ships with a
persistent local client out of the box (`chromadb.PersistentClient`), needs
no separate DB server process, supports metadata filtering natively, and has
a mature Python API. It runs entirely inside the FastAPI process and
persists to `./data/chroma_store/` — the only cost is disk space, unlike a
managed pod that bills 24/7 whether or not you're querying it. See
`eval/cost_analysis.py` for the quantified comparison.

## Architecture

```
Client → FastAPI (/ingest, /query)
              │
   ┌──────────┴──────────┐
   │                      │
Ingestion             RAG Pipeline
(load → chunk →       (embed query → top-k search →
 hash → dedup)         threshold/fallback → grounded
   │                    prompt → Claude → cited answer)
   ▼                      │
ChromaDB  ◄────embed──────┘
(persistent, on-disk)
```

## Setup

```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # then add your ANTHROPIC_API_KEY
```

Drop PDF / HTML / MD / TXT files into `data/raw_documents/` (four samples
are included), then:

```bash
uvicorn src.api:app --reload
```

- `POST /ingest` — `{"paths": [...]}` (omit `paths` to ingest everything
  under `data/raw_documents/`). Idempotent: re-running it inserts 0
  duplicate vectors, because every chunk id is
  `SHA256(source_path + chunk_index + text)` and existing ids are
  filtered out before insert.
- `POST /query` — `{"query": "...", "top_k": 5, "metadata_filter": {"file_type": "pdf"}}`
  → grounded answer + per-chunk citations + latency/token/cost metrics.
- `GET /stats`, `GET /health`.

### Embedding backend

Two backends, selected via `EMBEDDING_BACKEND` in `.env`:
- `sentence_transformers` (default): real semantic embeddings via
  `all-MiniLM-L6-v2` (384-dim). Needs one-time internet access to download
  the model.
- `hashing`: a deterministic, fully offline bag-of-hashed-words fallback.
  Not semantically meaningful, but lets the entire pipeline — ingestion,
  idempotency, storage, retrieval metrics, cost math — be exercised in
  network-restricted environments (e.g. CI, or sandboxes without
  model-hub access). If `sentence_transformers` fails to load the model
  (no network), the app automatically falls back to `hashing` rather than
  crashing.

**Note:** the sample runs in this repo's dev environment used the
`hashing` backend (no model-hub access there), so the retrieval numbers in
`results/` reflect a much weaker embedder than you'll get with
`all-MiniLM-L6-v2` in a normal environment with internet access — re-run
the eval scripts after switching backends to get representative numbers.

## Evaluation

```bash
python -m eval.evaluate_retrieval   # Recall@k, Hit Rate, MRR, nDCG@k, Context Precision
python -m eval.evaluate_answer      # Faithfulness + Relevance (LLM-as-judge) + EM/F1
python -m eval.cost_analysis        # cost table + p50/p95 latency from logs/query_log.jsonl
```

Each writes a results file to `results/`. `data/eval_dataset.json` has 15
fixed questions with gold `relevant_chunk_ids` (computed against the sample
docs — regenerate if you replace the corpus).

Sample run (offline `hashing` embedder, no LLM key — see caveats above):

| Metric | Value |
|---|---|
| Mean Recall@5 | 0.933 |
| Mean Hit Rate@5 | 0.933 |
| Mean MRR | 0.867 |
| Mean nDCG@5 | 0.884 |
| Mean Context Precision@5 | 0.187 |

Context precision is low here simply because `top_k=5` on a 12-chunk corpus
is a high denominator relative to 1 gold chunk per question — an expected
artifact of the toy corpus, not a retrieval bug (confirmed by high
Recall/MRR/nDCG on the same runs).

Faithfulness/Relevance show as `null` and Answer eval falls back to a
placeholder answer whenever `ANTHROPIC_API_KEY` isn't set — the harness
degrades gracefully instead of crashing or fabricating a score.

## Cost model (see `eval/cost_analysis.py` for full assumptions)

| Vectors | Storage (GB) | Embedded cost/mo | Managed DB cost/mo | Savings |
|---|---|---|---|---|
| 100K | 0.19 | ~$25 | ~$70 | 64% |
| 1M | 1.9 | ~$25 | ~$280 | 91% |
| 10M | 19.0 | ~$27 | ~$1,200 | 98% |

Assumptions: 384-dim float32 vectors, ~0.5KB metadata/vector, $0.08/GB/mo
disk, a flat $25/mo shared-compute share (same small always-on
process serves the embedded store regardless of scale in this range), and
illustrative managed-DB pod tiers ($70 / $280 / $1200). Query volume
(50K/mo) doesn't change the embedded cost because disk-backed ANN search
has no per-query billing — only compute for the query itself, which is
already inside the flat compute share.

## Discussion

**When would you switch back to managed?** Once the index no longer fits
on one machine's disk/RAM (rough line: tens of millions of vectors), or
once you need multi-region replication / a formal uptime SLA / horizontal
query fan-out that a single embedded process can't give you. Below that,
the embedded store is both cheaper and — per the latency numbers — fast
enough (single-digit-ms p50 retrieval in this test).

**Was retrieval or generation the weak link?** In this sample run,
retrieval was solid (Recall/MRR/nDCG all high) even with a deliberately
weak offline embedder — the fallback threshold correctly gated a couple of
low-similarity queries. Generation is the harder link to assess without a
live LLM key: the graceful-degrade path shows the plumbing (prompt
construction, token accounting, cost logging) is correct, but real
faithfulness/relevance numbers require running `evaluate_answer.py` with
`ANTHROPIC_API_KEY` set — do that before trusting the answer-quality claim
in production.

## Project structure

```
cost-efficient-rag/
├── data/
│   ├── raw_documents/       # sample .md / .html / .pdf / .txt
│   └── eval_dataset.json    # 15 fixed Q/A pairs with gold chunk ids
├── src/
│   ├── config.py            # env-driven settings (pydantic-settings)
│   ├── ingestion.py         # loaders, chunking, SHA-256 idempotent ids
│   ├── embeddings.py        # sentence-transformers | hashing fallback
│   ├── vector_store.py      # ChromaDB persistent client wrapper
│   ├── rag_pipeline.py      # retrieval → fallback → prompt → Claude
│   ├── logger.py            # JSONL per-query latency/token/cost log
│   └── api.py                # FastAPI: /ingest /query /stats /health
├── eval/
│   ├── evaluate_retrieval.py
│   ├── evaluate_answer.py
│   └── cost_analysis.py
├── results/                  # generated by the eval scripts
├── .env.example
├── requirements.txt
└── README.md
```
