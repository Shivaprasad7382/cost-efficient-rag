# Choosing a Vector Database

## Embedded vs Managed

Embedded vector stores such as ChromaDB, LanceDB, and FAISS run directly
inside your application process, or as a lightweight disk-backed library.
They have zero base compute cost when idle, unlike managed cloud vector
databases which typically charge $70 to $300 per month for a minimal
always-on pod, regardless of how many queries you actually run.

## When to choose a managed vector database

Managed vector databases make sense once you need multi-region replication,
strict uptime SLAs, or your index no longer fits comfortably on a single
machine's disk and RAM. Below roughly 10 million vectors with moderate
query volume, a self-hosted embedded store is usually far cheaper and just
as fast for most workloads.

## Chunking strategy

Recursive character chunking with a small overlap (for example 500
characters with a 50 character overlap) tends to preserve enough context at
chunk boundaries to avoid truncating important sentences, while keeping
retrieval precise. Larger chunks increase recall but dilute precision,
since more irrelevant text gets pulled into the LLM's context window.

## Idempotent ingestion

To make re-ingestion safe, compute a deterministic id for every chunk, for
example a SHA-256 hash of the source path, chunk index, and chunk text.
Before inserting new vectors, check which ids already exist in the store
and skip those chunks. This guarantees that running the ingestion pipeline
twice on the same document never creates duplicate vectors.
