"""
Embedding backend abstraction.

Two backends are supported:
  - "sentence_transformers": real semantic embeddings (all-MiniLM-L6-v2, 384-dim
    by default). Requires the model to be downloaded once (needs internet /
    HF hub access).
  - "hashing": a fully offline, deterministic bag-of-words hashing vectorizer.
    Not semantically meaningful, but useful so the pipeline can be exercised
    end-to-end (ingestion, dedup, storage, metrics) in network-restricted
    environments (e.g. CI) without downloading a model.

Both implement the same `.encode(list[str]) -> list[list[float]]` interface
and expose `.dim`, so the rest of the app is agnostic to which is active.
"""
from __future__ import annotations

import hashlib
import math
import re
from typing import List

from .config import settings


class HashingEmbedder:
    """Deterministic, offline, dependency-free embedder (bag-of-hashed-words)."""

    def __init__(self, dim: int = 384):
        self.dim = dim

    def _vector_for(self, text: str) -> List[float]:
        vec = [0.0] * self.dim
        tokens = re.findall(r"[a-z0-9]+", text.lower())
        if not tokens:
            return vec
        for tok in tokens:
            h = int(hashlib.sha256(tok.encode("utf-8")).hexdigest(), 16)
            idx = h % self.dim
            sign = 1.0 if (h // self.dim) % 2 == 0 else -1.0
            vec[idx] += sign
        norm = math.sqrt(sum(v * v for v in vec)) or 1.0
        return [v / norm for v in vec]

    def encode(self, texts: List[str]) -> List[List[float]]:
        return [self._vector_for(t) for t in texts]


class SentenceTransformerEmbedder:
    """Wraps sentence-transformers for real semantic embeddings."""

    def __init__(self, model_name: str):
        from sentence_transformers import SentenceTransformer  # lazy import

        self.model = SentenceTransformer(model_name)
        self.dim = self.model.get_sentence_embedding_dimension()

    def encode(self, texts: List[str]) -> List[List[float]]:
        vectors = self.model.encode(texts, normalize_embeddings=True)
        return vectors.tolist()


_embedder = None


def get_embedder():
    global _embedder
    if _embedder is not None:
        return _embedder

    if settings.embedding_backend == "hashing":
        _embedder = HashingEmbedder(dim=settings.embedding_dim)
    else:
        try:
            _embedder = SentenceTransformerEmbedder(settings.embedding_model_name)
        except Exception as exc:  # model hub unreachable, package missing, etc.
            import logging

            logging.getLogger(__name__).warning(
                "Falling back to HashingEmbedder — could not load "
                "sentence-transformers model '%s': %s",
                settings.embedding_model_name,
                exc,
            )
            _embedder = HashingEmbedder(dim=settings.embedding_dim)
    return _embedder
