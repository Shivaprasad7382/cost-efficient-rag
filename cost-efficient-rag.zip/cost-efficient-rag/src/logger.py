"""
Structured per-query logging: retrieval latency, generation latency, chunk
count, token usage, and estimated cost. Written as JSON Lines so the eval
harness can easily compute p50/p95 later.
"""
from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict

from loguru import logger as _loguru_logger

from .config import settings

Path(settings.log_dir).mkdir(parents=True, exist_ok=True)
QUERY_LOG_PATH = Path(settings.log_dir) / "query_log.jsonl"

_loguru_logger.add(Path(settings.log_dir) / "app.log", rotation="5 MB")


class Timer:
    """Small helper: `with Timer() as t: ...` then `t.elapsed_ms`."""

    def __enter__(self):
        self._start = time.perf_counter()
        return self

    def __exit__(self, *exc):
        self.elapsed_ms = (time.perf_counter() - self._start) * 1000.0


def log_query_event(event: Dict[str, Any]) -> None:
    event = {"timestamp": time.time(), **event}
    with open(QUERY_LOG_PATH, "a", encoding="utf-8") as f:
        f.write(json.dumps(event) + "\n")
    _loguru_logger.info("query_event: {}", event)


def read_query_log() -> list[Dict[str, Any]]:
    if not QUERY_LOG_PATH.exists():
        return []
    with open(QUERY_LOG_PATH, "r", encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]
