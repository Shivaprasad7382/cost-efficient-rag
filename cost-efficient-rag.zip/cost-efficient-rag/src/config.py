"""
Central configuration for the cost-efficient RAG app.

All values are loaded from environment variables (see .env.example). Nothing
is ever hardcoded here — copy .env.example to .env and fill in your own key.
"""
from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    # LLM
    anthropic_api_key: str = ""
    generation_model: str = "claude-sonnet-4-6"

    # Vector store
    vector_store_path: str = "./data/chroma_store"
    collection_name: str = "rag_chunks"

    # Embeddings
    embedding_backend: str = "sentence_transformers"  # or "hashing"
    embedding_model_name: str = "all-MiniLM-L6-v2"
    embedding_dim: int = 384

    # Chunking
    default_chunk_size: int = 500
    default_chunk_overlap: int = 50

    # Retrieval
    default_top_k: int = 5
    similarity_threshold: float = 0.25

    # Logging
    log_dir: str = "./logs"


settings = Settings()
