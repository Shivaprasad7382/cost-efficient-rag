"""
Embedded vector store interface (ChromaDB, persistent-on-disk client).

ChromaDB runs in-process and persists to a local directory, so there is no
always-on managed pod / cluster to pay for — this is the core cost lever the
assignment asks us to exploit. See eval/cost_analysis.py for the numbers.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Set

import chromadb

from .config import settings
from .embeddings import get_embedder
from .ingestion import ChunkRecord


class VectorStoreManager:
    def __init__(self, db_path: str | None = None, collection_name: str | None = None):
        self.db_path = db_path or settings.vector_store_path
        self.collection_name = collection_name or settings.collection_name
        self.client = chromadb.PersistentClient(path=self.db_path)
        self.collection = self.client.get_or_create_collection(
            name=self.collection_name, metadata={"hnsw:space": "cosine"}
        )
        self.embedder = get_embedder()

    # ---- ids / idempotence -------------------------------------------------

    def existing_ids(self) -> Set[str]:
        """Pull all ids currently stored (used to filter out dup chunks)."""
        result = self.collection.get(include=[])  # ids are always returned
        return set(result.get("ids", []))

    # ---- writes -------------------------------------------------------------

    def upsert_records(self, records: List[ChunkRecord]) -> int:
        """Embed + insert new chunk records. Returns count actually inserted."""
        if not records:
            return 0
        vectors = self.embedder.encode([r.text for r in records])
        self.collection.add(
            ids=[r.id for r in records],
            embeddings=vectors,
            documents=[r.text for r in records],
            metadatas=[
                {
                    "source": r.source,
                    "chunk_index": r.chunk_index,
                    "file_type": r.file_type,
                    **r.metadata,
                }
                for r in records
            ],
        )
        return len(records)

    # ---- reads ---------------------------------------------------------------

    def search(
        self,
        query: str,
        top_k: int = 5,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> List[Dict[str, Any]]:
        query_vector = self.embedder.encode([query])[0]
        where = metadata_filter if metadata_filter else None
        result = self.collection.query(
            query_embeddings=[query_vector],
            n_results=top_k,
            where=where,
            include=["documents", "metadatas", "distances"],
        )
        out = []
        ids = result.get("ids", [[]])[0]
        docs = result.get("documents", [[]])[0]
        metas = result.get("metadatas", [[]])[0]
        dists = result.get("distances", [[]])[0]
        for cid, doc, meta, dist in zip(ids, docs, metas, dists):
            # Chroma with cosine space returns distance = 1 - cosine_similarity
            similarity = 1.0 - dist
            out.append(
                {
                    "id": cid,
                    "text": doc,
                    "source": meta.get("source"),
                    "chunk_index": meta.get("chunk_index"),
                    "file_type": meta.get("file_type"),
                    "similarity": similarity,
                }
            )
        return out

    def count(self) -> int:
        return self.collection.count()
