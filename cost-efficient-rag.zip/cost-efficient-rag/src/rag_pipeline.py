"""
Top-k retrieval -> grounded prompt construction -> LLM answer with citations.

Fallback: if no chunks clear the similarity threshold, we never call the LLM
and just return the fixed "insufficient context" message (saves cost too).
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional

from .config import settings
from .logger import Timer, log_query_event
from .vector_store import VectorStoreManager

FALLBACK_MESSAGE = (
    "I do not have sufficient information in the provided context to answer this question."
)

SYSTEM_PROMPT_TEMPLATE = """You are a precise QA assistant. Answer the user question using ONLY the context provided below.
For every factual claim, cite the source using the chunk id in brackets, like [Doc: <source>, Chunk: <chunk_index>].
If the provided context does not contain enough information to answer the question, respond with EXACTLY this text and nothing else:
"{fallback}"

Context:
{context_block}
"""

# Rough per-model $ / 1K tokens for cost logging. Update to match your actual
# provider pricing; these are illustrative placeholders.
PRICING_PER_1K_TOKENS = {
    "claude-sonnet-4-6": {"input": 0.003, "output": 0.015},
}


def _estimate_tokens(text: str) -> int:
    # Cheap, provider-agnostic approximation: ~4 chars/token for English text.
    return max(1, len(text) // 4)


def build_prompt(query: str, retrieved_chunks: List[Dict[str, Any]]) -> Optional[str]:
    if not retrieved_chunks:
        return None
    formatted = [
        f"[Doc: {c['source']}, Chunk: {c['chunk_index']}]\n{c['text']}" for c in retrieved_chunks
    ]
    context_block = "\n\n".join(formatted)
    return SYSTEM_PROMPT_TEMPLATE.format(fallback=FALLBACK_MESSAGE, context_block=context_block)


def _call_llm(system_prompt: str, query: str) -> Dict[str, Any]:
    """
    Calls Anthropic's Messages API. Requires ANTHROPIC_API_KEY to be set.
    Returns dict with `text`, `input_tokens`, `output_tokens`.
    """
    import anthropic

    client = anthropic.Anthropic(api_key=settings.anthropic_api_key)
    response = client.messages.create(
        model=settings.generation_model,
        max_tokens=1000,
        system=system_prompt,
        messages=[{"role": "user", "content": query}],
    )
    text = "".join(block.text for block in response.content if block.type == "text")
    usage = response.usage
    return {
        "text": text,
        "input_tokens": usage.input_tokens,
        "output_tokens": usage.output_tokens,
    }


class RAGPipeline:
    def __init__(self, store: Optional[VectorStoreManager] = None):
        self.store = store or VectorStoreManager()

    def answer(
        self,
        query: str,
        top_k: int = settings.default_top_k,
        metadata_filter: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        with Timer() as t_retrieval:
            candidates = self.store.search(query, top_k=top_k, metadata_filter=metadata_filter)

        # apply similarity threshold -> fallback logic
        passing = [c for c in candidates if c["similarity"] >= settings.similarity_threshold]

        result: Dict[str, Any] = {
            "query": query,
            "chunks_retrieved": len(candidates),
            "chunks_used": len(passing),
            "retrieval_latency_ms": round(t_retrieval.elapsed_ms, 2),
            "citations": [
                {"source": c["source"], "chunk_index": c["chunk_index"], "similarity": round(c["similarity"], 4)}
                for c in passing
            ],
        }

        if not passing:
            result["answer"] = FALLBACK_MESSAGE
            result["generation_latency_ms"] = 0.0
            result["prompt_tokens"] = 0
            result["completion_tokens"] = 0
            result["estimated_cost_usd"] = 0.0
            result["fallback_triggered"] = True
            log_query_event(result)
            return result

        prompt = build_prompt(query, passing)

        with Timer() as t_generation:
            try:
                llm_out = _call_llm(prompt, query)
                answer_text = llm_out["text"]
                in_tok, out_tok = llm_out["input_tokens"], llm_out["output_tokens"]
            except Exception as exc:
                # No API key / network issue in this environment — degrade
                # gracefully instead of crashing the whole request.
                answer_text = (
                    "[LLM call failed — set ANTHROPIC_API_KEY to enable generation] "
                    f"Retrieved {len(passing)} relevant chunk(s) but could not "
                    f"synthesize an answer ({exc.__class__.__name__})."
                )
                in_tok = _estimate_tokens(prompt)
                out_tok = _estimate_tokens(answer_text)

        pricing = PRICING_PER_1K_TOKENS.get(settings.generation_model, {"input": 0.003, "output": 0.015})
        cost = (in_tok / 1000) * pricing["input"] + (out_tok / 1000) * pricing["output"]

        result["answer"] = answer_text
        result["generation_latency_ms"] = round(t_generation.elapsed_ms, 2)
        result["prompt_tokens"] = in_tok
        result["completion_tokens"] = out_tok
        result["estimated_cost_usd"] = round(cost, 6)
        result["fallback_triggered"] = False

        log_query_event(result)
        return result
