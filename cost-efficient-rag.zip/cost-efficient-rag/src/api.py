"""
HTTP interface for the cost-efficient RAG service.

POST /ingest  - ingest one or more raw_documents/ files (idempotent)
POST /query   - ask a question, get a grounded, cited answer
GET  /health  - liveness check
GET  /stats   - vector count etc.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional

from fastapi import FastAPI
from pydantic import BaseModel, Field

from .config import settings
from .ingestion import build_chunk_records, deduplicate
from .rag_pipeline import RAGPipeline
from .vector_store import VectorStoreManager

app = FastAPI(title="Cost-Efficient RAG Service", version="1.0.0")

_store = VectorStoreManager()
_pipeline = RAGPipeline(store=_store)


class IngestRequest(BaseModel):
    paths: Optional[List[str]] = Field(
        default=None,
        description="Explicit file paths to ingest. If omitted, all files under data/raw_documents/ are ingested.",
    )
    chunk_size: int = settings.default_chunk_size
    chunk_overlap: int = settings.default_chunk_overlap


class IngestResponse(BaseModel):
    files_processed: int
    chunks_seen: int
    chunks_inserted: int
    chunks_skipped_duplicate: int
    total_vectors_in_store: int


class QueryRequest(BaseModel):
    query: str
    top_k: int = settings.default_top_k
    metadata_filter: Optional[Dict[str, Any]] = None


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/stats")
def stats():
    return {"total_vectors": _store.count(), "collection": _store.collection_name}


@app.post("/ingest", response_model=IngestResponse)
def ingest(req: IngestRequest):
    if req.paths:
        paths = [Path(p) for p in req.paths]
    else:
        raw_dir = Path("data/raw_documents")
        paths = [p for p in raw_dir.glob("**/*") if p.is_file()]

    existing_ids = _store.existing_ids()
    all_new_records = []
    chunks_seen = 0

    for path in paths:
        records = build_chunk_records(path, chunk_size=req.chunk_size, chunk_overlap=req.chunk_overlap)
        chunks_seen += len(records)
        new_records = deduplicate(records, existing_ids)
        all_new_records.extend(new_records)
        existing_ids.update(r.id for r in new_records)

    inserted = _store.upsert_records(all_new_records)

    return IngestResponse(
        files_processed=len(paths),
        chunks_seen=chunks_seen,
        chunks_inserted=inserted,
        chunks_skipped_duplicate=chunks_seen - inserted,
        total_vectors_in_store=_store.count(),
    )


@app.post("/query")
def query(req: QueryRequest):
    return _pipeline.answer(req.query, top_k=req.top_k, metadata_filter=req.metadata_filter)
