"""
Document ingestion pipeline.

Responsibilities:
  1. Load raw text out of PDF / HTML / Markdown files.
  2. Split text into overlapping chunks (configurable size/overlap).
  3. Generate a deterministic SHA-256 chunk id so re-ingesting the same
     document never creates duplicate vectors (idempotence).
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Set

from bs4 import BeautifulSoup
from pypdf import PdfReader
import markdown as md_lib

from .config import settings


# --------------------------------------------------------------------------
# 1. File loaders -> raw text
# --------------------------------------------------------------------------

def load_pdf(path: Path) -> str:
    reader = PdfReader(str(path))
    pages = [page.extract_text() or "" for page in reader.pages]
    return "\n\n".join(pages)


def load_html(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    soup = BeautifulSoup(raw, "html.parser")
    for tag in soup(["script", "style"]):
        tag.decompose()
    return soup.get_text(separator="\n")


def load_markdown(path: Path) -> str:
    raw = path.read_text(encoding="utf-8", errors="ignore")
    html = md_lib.markdown(raw)
    soup = BeautifulSoup(html, "html.parser")
    return soup.get_text(separator="\n")


def load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


LOADERS = {
    ".pdf": load_pdf,
    ".html": load_html,
    ".htm": load_html,
    ".md": load_markdown,
    ".markdown": load_markdown,
    ".txt": load_text,
}


def load_document(path: Path) -> str:
    ext = path.suffix.lower()
    loader = LOADERS.get(ext)
    if loader is None:
        raise ValueError(f"Unsupported file type: {ext}")
    return loader(path)


def file_type_of(path: Path) -> str:
    ext = path.suffix.lower()
    if ext == ".pdf":
        return "pdf"
    if ext in (".html", ".htm"):
        return "html"
    if ext in (".md", ".markdown"):
        return "md"
    return "txt"


# --------------------------------------------------------------------------
# 2. Recursive-ish character chunking with overlap
# --------------------------------------------------------------------------

def chunk_text(
    text: str,
    chunk_size: int = settings.default_chunk_size,
    chunk_overlap: int = settings.default_chunk_overlap,
) -> List[str]:
    """
    Split on paragraph/sentence boundaries where possible, falling back to a
    hard character cut, always respecting chunk_size with chunk_overlap
    characters repeated between consecutive chunks.
    """
    text = text.strip()
    if not text:
        return []
    if chunk_overlap >= chunk_size:
        raise ValueError("chunk_overlap must be smaller than chunk_size")

    # Prefer splitting on paragraph breaks, then sentences, then words.
    separators = ["\n\n", "\n", ". ", " "]

    def _split(t: str, seps: List[str]) -> List[str]:
        if not seps:
            return [t]
        sep = seps[0]
        parts = [p for p in t.split(sep) if p != ""]
        return parts if len(parts) > 1 else _split(t, seps[1:]) if len(seps) > 1 else [t]

    units = _split(text, separators)

    chunks: List[str] = []
    current = ""
    for unit in units:
        candidate = (current + " " + unit).strip() if current else unit
        if len(candidate) <= chunk_size:
            current = candidate
        else:
            if current:
                chunks.append(current)
            # start new chunk, carrying `chunk_overlap` chars of tail context
            tail = current[-chunk_overlap:] if current else ""
            current = (tail + " " + unit).strip() if tail else unit
            # if a single unit is itself bigger than chunk_size, hard-slice it
            while len(current) > chunk_size:
                chunks.append(current[:chunk_size])
                current = current[chunk_size - chunk_overlap:]
    if current:
        chunks.append(current)

    return chunks


# --------------------------------------------------------------------------
# 3. Deterministic chunk IDs + idempotent dedup
# --------------------------------------------------------------------------

def generate_chunk_id(source_path: str, chunk_index: int, text: str) -> str:
    """SHA256(source_path + chunk_index + text) -> stable id."""
    raw_identifier = f"{source_path}_{chunk_index}_{text}"
    return hashlib.sha256(raw_identifier.encode("utf-8")).hexdigest()


@dataclass
class ChunkRecord:
    id: str
    text: str
    source: str
    chunk_index: int
    file_type: str
    metadata: Dict[str, Any] = field(default_factory=dict)


def build_chunk_records(
    path: Path,
    chunk_size: int = settings.default_chunk_size,
    chunk_overlap: int = settings.default_chunk_overlap,
    extra_metadata: Dict[str, Any] | None = None,
) -> List[ChunkRecord]:
    text = load_document(path)
    pieces = chunk_text(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
    ftype = file_type_of(path)
    records = []
    for idx, piece in enumerate(pieces):
        cid = generate_chunk_id(str(path), idx, piece)
        records.append(
            ChunkRecord(
                id=cid,
                text=piece,
                source=str(path.name),
                chunk_index=idx,
                file_type=ftype,
                metadata=extra_metadata or {},
            )
        )
    return records


def deduplicate(records: List[ChunkRecord], existing_ids: Set[str]) -> List[ChunkRecord]:
    """Filter out any chunk whose id is already present in the vector store."""
    return [r for r in records if r.id not in existing_ids]
